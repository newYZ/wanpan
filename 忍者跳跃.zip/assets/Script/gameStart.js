cc.Class({
    extends: cc.Component,

    properties: {
    },

    onLoad: function () {
        this.playMusic("sound/background", true);
    },

    //开始按钮回调
    startBtnCallBack : function(event, customEventData){
        this.playSound("sound/click", false);
        //显示游戏界面
        cc.log("startBtnCallBack"); 
        cc.director.preloadScene('playScene', function () {
            cc.director.loadScene('playScene');
        });
    },

    //播放音效
    playSound : function(name, isLoop){
        cc.loader.loadRes(name, cc.AudioClip, function (err, clip) {
            if(err){
                return;
            }
            let audioID = cc.audioEngine.playEffect(clip, isLoop);
        });
    },

    //播放音乐
    playMusic : function(name, isLoop){
        cc.loader.loadRes(name, cc.AudioClip, function (err, clip) {
            if(err){
                return;
            }
            let audioID = cc.audioEngine.playMusic(clip, isLoop);
        });
    },

    update: function (dt) {

    },
});
