let OBS_COLUMN = 1;  //障碍物--柱子
let OBS_DARTS = 2; //障碍物--飞镖
let OBS_CAKE = 3; // 障碍物--蛋糕

let CAKE_OFFSET = 45;  //蛋糕坐标偏移量
let DARTS_OFFSET = 48; //飞镖坐标偏移量
let COLUMN0_OFFSET = 105; //长柱子坐标偏移量
let COLUMN1_OFFSET = 65; //短柱子坐标偏移量
 

cc.Class({
    extends: cc.Component,

    properties: {
        bgImg : cc.Node,

        //提示层
        tipsLayer : cc.Node,

        //障碍物层
        obsLayer : cc.Node,

        //英雄
        heroImg : cc.Node,

        //血量
        heroBloodBar : cc.ProgressBar,

        //得分
        scoreText : cc.Label,

        //结算层
        gameOverLayer : cc.Node,

        //结算米数
        resultScoreText : cc.Label,

        //障碍物预制体
        obsCakePrefab : cc.Prefab,
        obsDartsPrefab : cc.Prefab,
        obsColumn0Prefab : cc.Prefab,
        obsColumn1Prefab : cc.Prefab,

        obsImgAtlas : cc.SpriteAtlas,
    },

    onLoad: function () {
        this._winSize = cc.winSize;
        //障碍物容器
        this._obsArrays = [];
        //游戏是否开始
        this._isStartGame = false;
        //英雄当前方向
        this._isLeft = true;
        //英雄跳的次数
        this._jumpCount = 0;
        //英雄血量
        this._heroBloodValue = 5;
        //得分
        this._curScore = 0;

        //开启物理系统
        cc.director.getPhysicsManager().enabled = true;
        //开启物理调试
        //cc.director.getPhysicsManager().debugDrawFlags = true;
        // 重力加速度的配置
        cc.director.getPhysicsManager().gravity = cc.v2(0, 0);

        //显示提示层
        this.tipsLayer.active = true;

        this.createFloor();

        //英雄碰撞监听
        this.heroContact();

        //屏幕触摸监听
        this.node.on(cc.Node.EventType.TOUCH_START, this.onEventStart, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.onEventEnd, this);
    },

    //创建地面
    createFloor () {
        this._wallArrays = [];
        let wallPosX = 0;
        let wallPosY = -this._winSize.height / 2; 

        while(wallPosY <= this._winSize.height / 2 + 60){
            var wallNode = new cc.Node();
            wallNode.parent = this.obsLayer;
            var wallSp = wallNode.addComponent(cc.Sprite);
            wallSp.spriteFrame = this.obsImgAtlas.getSpriteFrame("wall");
            wallNode.position = cc.v2(wallPosX, wallPosY);
            wallPosY += 60;
            this._wallArrays.push(wallNode);
        }
    },

    //创建障碍物
    createObs(node){
        let obsType = Math.floor(Math.random() * 100);
        let isLeft = Math.floor(Math.random() * 100) % 2; 
        cc.log("obsType = ", obsType);
        //小于70无障碍物  70~80柱子  81~95飞镖 95蛋糕
        //柱子
        if(obsType >= 70 && obsType < 80){
            let type = Math.floor(Math.random() * 100) % 4; 
            let columnNode = cc.instantiate(type == 0 ? this.obsColumn0Prefab : this.obsColumn1Prefab);
            if(isLeft){
                columnNode.position = cc.v2(type == 0 ? -COLUMN0_OFFSET : -COLUMN1_OFFSET, node.position.y);
                columnNode.scaleX = 1;
            }
            else{
                columnNode.position = cc.v2(type == 0 ? COLUMN0_OFFSET : COLUMN1_OFFSET, node.position.y);
                columnNode.scaleX = -1;
            }
            columnNode.parent = this.obsLayer;
            this._obsArrays.push(columnNode);
        }
        //飞镖 
        else if(obsType >= 80 && obsType <= 95){
            let dartsNode = cc.instantiate(this.obsDartsPrefab);
            if(isLeft){
                dartsNode.position = cc.v2(-DARTS_OFFSET, node.position.y);
                dartsNode.scaleX = 1;
            }
            else{
                dartsNode.position = cc.v2(DARTS_OFFSET, node.position.y);
                dartsNode.scaleX = -1;
            }
            dartsNode.parent = this.obsLayer;
            //飞镖旋转动画
            dartsNode.runAction(cc.repeatForever(cc.rotateBy(1.0, 360)));
            this._obsArrays.push(dartsNode);
        }
        //蛋糕
        else if(obsType > 95){
            let cakeNode = cc.instantiate(this.obsCakePrefab);
            if(isLeft){
                cakeNode.position = cc.v2(-CAKE_OFFSET, node.position.y);
                cakeNode.scaleY = 1;
            }
            else{
                cakeNode.position = cc.v2(CAKE_OFFSET, node.position.y);
                cakeNode.scaleY = -1;
            }
            cakeNode.parent = this.obsLayer;
            this._obsArrays.push(cakeNode);
        }
        else{

        }
    },

    //地面运动
    floorAni(){
        //木条运动
        for(let i = 0; i < this._wallArrays.length; i++){
            let wallNode = this._wallArrays[i];
            if(wallNode.position.y <= -this._winSize.height / 2 - 30){  
                //重置位置                         
                wallNode.position = cc.v2(0, this._winSize.height / 2 + 30);
                this.createObs(wallNode);
                this._curScore += 1;
                this.updateScore();
            }
            wallNode.position = cc.v2(0, wallNode.position.y - 5);
        }
    },

    //障碍物运动
    obsAni(){
        let count = this._obsArrays.length;
        for(let i = 0; i < this._obsArrays.length; ){
            let obsNode = this._obsArrays[i];
            if(obsNode.position.y <= -this._winSize.height / 2 - 30){  
                obsNode.removeFromParent();
                this._obsArrays.splice(i, 1);
            }
            else{
                obsNode.position = cc.v2(obsNode.position.x, obsNode.position.y - 5);
                i++;
            }
        }
    },

    //英雄碰撞监听
    heroContact(){
        this.heroImg.getComponent("contact").contactCallBack((selfCollider, otherCollider) => {
            let bodyGroup0 = selfCollider.node.group;
            let bodyGroup1 = otherCollider.node.group;

            //英雄和地面碰撞
            if((bodyGroup0 == "hero" && bodyGroup1 == "floor") 
            || (bodyGroup0 == "floor" && bodyGroup1 == "hero")){
                //有跳起
                if(this._jumpCount > 0){
                    this._jumpCount = 0;
                }
            }

            //英雄和蛋糕道具碰撞
            if((bodyGroup0 == "hero" && bodyGroup1 == "prop") 
            || (bodyGroup0 == "prop" && bodyGroup1 == "hero")){
                //道具隐藏
                let prop = null;
                if(bodyGroup0 == "prop"){
                    prop = selfCollider;
                }
                if(bodyGroup1 == "prop"){
                    prop = otherCollider;
                }
                prop.node.active = false;

                //英雄加血
                this.updateBlood(1);
                this.playSound("sound/add_time");
            }

            //英雄和飞镖碰撞
            if((bodyGroup0 == "hero" && bodyGroup1 == "darts") 
            || (bodyGroup0 == "darts" && bodyGroup1 == "hero")){
                //英雄闪烁
                this.heroImg.opacity = 255;
                this.heroImg.runAction(cc.blink(0.3, 2));
                
                //移除飞镖刚体
                let darts = null;
                if(bodyGroup0 == "darts"){
                    darts = selfCollider;
                }
                if(bodyGroup1 == "darts"){
                    darts = otherCollider;
                }
                darts.node.active = false;
                //英雄减血
                this.updateBlood(-1);
                this.playSound("sound/darts");
            }

             //英雄和柱子碰撞
             if((bodyGroup0 == "hero" && bodyGroup1 == "column") 
             || (bodyGroup0 == "column" && bodyGroup1 == "hero")){
                this.playSound("sound/die");
                //英雄减血
                this.updateBlood(-5);
                 //游戏结束
                 this.gameOver();
             }

            this.heroImg.position.y = 0;
        });
    },

    //屏幕触摸回调
    onEventStart : function(event){
        if(this._isStartGame == true){
            let touchPos = event.getLocation();
            if(touchPos.x < this._winSize.width / 2){ //点击的左边
                if(this._isLeft){ //英雄在左边
                    this.heroJumpAni();
                }
                else{
                    this.setHeroDir(true);
                }

            }
            else{ // 点击的右边
                if(!this._isLeft){ //英雄在右边
                    this.heroJumpAni();
                }
                else{
                    this.setHeroDir(false);
                }
            }
        }
    },

    onEventEnd : function(event){
    },

    //提示层点击的回调
    tipsCallBack(event, customEventData){
        this.playSound("sound/click", false);
        this.tipsLayer.active = false;

        //设置游戏开始
        this._isStartGame = true;

        // 重力加速度的配置
        cc.director.getPhysicsManager().gravity = cc.v2(-320, 0);

        //播放英雄跑的动画
        this.heroImg.getComponent("spriteFrameAni").playAni("hero", 12, 0.04, true);

        this.setHeroDir(true);
    },

    //再来一局回调
    againCallBak : function(){
        this.playSound("sound/click", false);
        cc.director.preloadScene('playScene', function () {
            cc.director.loadScene('playScene');
        });
    },
    
    // 按钮的回调
    exitCallBack : function(event, customEventData){
        
    },

    //设置英雄方向
    setHeroDir : function(isLeft){
        //跳起状态不能改变方向
        if(this._jumpCount > 0){
            return;
        }
        this.playSound("sound/walk", false);
        this._isLeft = isLeft;
        let posX = 95;
        let scaleX = 0.6;
        //左边
        if(isLeft){
            this.heroImg.position = cc.v2(-posX, 0);
            this.heroImg.scaleX = -scaleX;
            // 重力加速度的配置
            cc.director.getPhysicsManager().gravity = cc.v2(980, 0);
        }
        else{
            this.heroImg.position = cc.v2(posX, 0);
            this.heroImg.scaleX = scaleX;
            // 重力加速度的配置
            cc.director.getPhysicsManager().gravity = cc.v2(-980, 0);
        }
    },

    //英雄跳跃
    heroJumpAni : function(){
        //跳跃次数小于2，允许连跳
        if(this._jumpCount < 2){
            this.playSound("sound/walk", false);
            this._jumpCount += 1;
            if(this._isLeft){
                this.heroImg.getComponent(cc.RigidBody).applyForceToCenter(cc.v2(-190000, 0));
            }
            else{
                this.heroImg.getComponent(cc.RigidBody).applyForceToCenter(cc.v2(190000, 0));
            }
        }
        else{ //已经跳了两次，需要先落地了才能再次跳跃

        }
    },

    //刷新血量值
    updateBlood : function(offset){
        this._heroBloodValue += offset;
        if(this._heroBloodValue > 5){
            this._heroBloodValue = 5;
        }
        if(this._heroBloodValue <= 0){
            //游戏结束
            this.gameOver();
        }
        let p = this._heroBloodValue / 5;
        this.heroBloodBar.progress = p;
    },

    //刷新得分
    updateScore : function(){
        this.scoreText.string = this._curScore + "m";
    },

    //游戏结束
    gameOver : function(){
        //设置游戏结束
        this._isStartGame = false;
        this.heroImg.stopAllActions();
        this.heroImg.opacity = 255;

        //显示结算界面
        this.gameOverLayer.active = true;
    
        this.resultScoreText.string = "恭喜你跑了" + this._curScore + "m";
    },

    //更换纹理
    setImgTexture : function(str, node){
        cc.loader.loadRes(str, cc.SpriteFrame, function (err, spriteFrame) {
            if (err) {
                cc.error(err.message || err);
                return;
            }
            node.getComponent(cc.Sprite).spriteFrame = spriteFrame;
        }.bind(this));
    },

    //播放音效
    playSound : function(name, isLoop){
        cc.loader.loadRes(name, cc.AudioClip, function (err, clip) {
            if(err){
                return;
            }
            var audioID = cc.audioEngine.playEffect(clip, isLoop);
        });
    },

    update: function (dt) {
        if(this._isStartGame == true){
            this.floorAni();
            this.obsAni();
        }
    },
});